export const environment = {
  production: true,
  firebaseConfig: {
    apiKey: "AIzaSyDZR8ggtuEManUsAa56h8a_fKWbwCtN9H4",
    authDomain: "schoolapp-c80c8.firebaseapp.com",
    projectId: "schoolapp-c80c8",
    storageBucket: "schoolapp-c80c8.appspot.com",
    messagingSenderId: "462231239480",
    appId: "1:462231239480:web:cba92014b5e6938d1f5fcd",
    measurementId: "G-NZE65MLR2B"
  }
};
