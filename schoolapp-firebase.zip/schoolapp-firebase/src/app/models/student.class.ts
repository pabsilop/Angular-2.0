export class Student {
    id: string;
    data: StudentData;
}

export class StudentData {
    firstName: string;
    lastName: string;
    age: number;
    course: string;
}